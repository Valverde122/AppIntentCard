package com.example.hito_dispositivosmoviles

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
//import kotlin.coroutines.jvm.internal.CompletedContinuation.context


class AdapterPlantillas(private val equipoS: Array<String>, private val mcontext:Context): RecyclerView.Adapter<AdapterPlantillas.PlantillaViewHolder>() {

    //en donde lo pinta, en la card de info_equipos
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlantillaViewHolder {
        val vista =LayoutInflater.from(parent.context).inflate(R.layout.info_equipos, parent, false)
        return PlantillaViewHolder(vista)
    }

    //como lo pinto, cojo la info del array pasado en el constructor y como lo pinto en la card
    override fun onBindViewHolder(holder: PlantillaViewHolder, position: Int) {
        val plantilla = equipoS[position]
        holder.nombre.text = plantilla

        holder.cardInfo.setOnClickListener() {
            Toast.makeText(mcontext, plantilla, Toast.LENGTH_LONG).show()

        }
    }

    //numero de veces que se repite
    override fun getItemCount(): Int {
            return equipoS.size
    }

    class PlantillaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val cardInfo: LinearLayout= itemView.findViewById(R.id.cardInfo)
        val nombre: TextView = itemView.findViewById(R.id.tvPais)

    }



}