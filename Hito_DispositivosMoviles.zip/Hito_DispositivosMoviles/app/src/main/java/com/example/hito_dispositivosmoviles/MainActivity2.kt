package com.example.hito_dispositivosmoviles

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)


        val info= findViewById<RecyclerView>(R.id.info)
        info.layoutManager = LinearLayoutManager(this)

        val listaEquipos = ArrayList<Equipo>()

        listaEquipos.add(Equipo("Real Madrid", "ESPAÑA", "Merengues"))
        listaEquipos.add(Equipo("Barcelona", "ESPAÑA", "Cules"))
        listaEquipos.add(Equipo("Atletico de Madrid", "ESPAÑA", "Colchoneros"))
        listaEquipos.add(Equipo("Sevilla", "ESPAÑA", "Palanganas"))
        listaEquipos.add(Equipo("Manchester City", "Inglaterra", "Sky Blues"))


        val adaptadorEquipo = AdaptaderEquipo(listaEquipos,this)
        info.adapter = adaptadorEquipo
    }
}