package com.example.hito_dispositivosmoviles

class Equipo {
    var nombre: String? = null
    var pais: String? = null
    var mote: String? = null

    constructor(nombre: String, pais: String, mote: String) {
        this.nombre = nombre
        this.pais = pais
        this.mote = mote
    }

}
