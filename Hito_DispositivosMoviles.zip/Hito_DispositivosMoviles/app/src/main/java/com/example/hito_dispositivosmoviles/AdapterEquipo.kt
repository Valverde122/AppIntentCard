package com.example.hito_dispositivosmoviles


import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import kotlin.coroutines.coroutineContext

class AdaptaderEquipo(val listaEquipos: List<Equipo>, private val context: Context): RecyclerView.Adapter<AdaptaderEquipo.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdaptaderEquipo.ViewHolder {
        val vista = LayoutInflater.from(parent.context).inflate(R.layout.info_equipos, parent, false)
        return ViewHolder(vista)
    }

    override fun onBindViewHolder(holder: AdaptaderEquipo.ViewHolder, position: Int) {
        val equipo = listaEquipos[position]

        holder.tvNombre.text = equipo.nombre
        holder.tvPais.text = equipo.pais
        holder.tvMote.text = equipo.mote
        holder.cardIf.setOnClickListener(){

            Toast.makeText(context, equipo.nombre,Toast.LENGTH_LONG).show()
            val plantilla=Intent(context,Plantilla::class.java)
            plantilla.putExtra("Plantilla", equipo.nombre)
            context.startActivity(plantilla)

            //val plantilla= context.startActivity(Intent(context, Plantilla::class.java))


        }
    }

    override fun getItemCount(): Int {
        return listaEquipos.size
    }

    class ViewHolder(ItemView: View): RecyclerView.ViewHolder(ItemView) {
        val tvNombre: TextView = itemView.findViewById(R.id.tvNombre)
        val tvPais: TextView = itemView.findViewById(R.id.tvPais)
        val tvMote: TextView = itemView.findViewById(R.id.tvMote)
        val cardIf: LinearLayout= itemView.findViewById(R.id.cardInfo)
    }
}