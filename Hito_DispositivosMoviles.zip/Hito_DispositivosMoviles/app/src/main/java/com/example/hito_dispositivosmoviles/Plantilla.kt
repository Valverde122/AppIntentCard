package com.example.hito_dispositivosmoviles

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Plantilla : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_plantilla)

        val equipo = intent.getStringExtra("Plantilla")
        val plantillas = mapOf(
            "Real Madrid" to arrayOf(
                "Courtois",
                "Militao",
                "Alaba",
                "Rudiguer",
                "Mendy",
                "Kroos",
                "Modric",
                "Valverde",
                "Vinicius",
                "Benzema",
                "Rodrygo"
            ),
            "Barcelona" to arrayOf(
                "Ter Stegen",
                "Pique",
                "Kounde",
                "Jordi Alba",
                "Araujo",
                "Gavi",
                "Pedri",
                "De Jong",
                "Depay",
                "Lewa",
                "Dembele"
            ),
            "Atletico de Madrid" to arrayOf(
                "Oblak",
                "Gimenez",
                "Hermoso",
                "Reinildo",
                "Reguilon",
                "Koke",
                "De paul",
                "Wistel",
                "Jao Felix",
                "Griezman",
                "Morata"
            ),
            "Sevilla" to arrayOf(
                "Bono",
                "Navas",
                "Acuña",
                "Marcao",
                "Gudelj",
                "Jordan",
                "Isco",
                "Oliver",
                "Rafa mir",
                "Lamela",
                "Dolberg"
            ),
            "Manchester City" to arrayOf(
                "Ederson",
                "Cancelo",
                "Laporte",
                "Dias",
                "Walker",
                "Bernardo",
                "Rodri",
                "De Bruyne",
                "Foden",
                "Haaland",
                "Mahrez"
            )
        )
        val equipoS = plantillas[equipo]
       // val adaptadorPlantilla = equipoS?.let { AdapterPlantillas(it,this)
        val adaptadorPlantilla = equipoS?.let { AdapterPlantillas(it,this) }
        val plant= findViewById<RecyclerView>(R.id.plantilla)
        plant.layoutManager = LinearLayoutManager(this)
        plant.adapter= adaptadorPlantilla
        println(plant)




    }
}//cierra oncreate
